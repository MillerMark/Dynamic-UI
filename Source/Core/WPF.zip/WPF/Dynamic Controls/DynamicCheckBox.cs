﻿using System;
using System.Reflection;
using System.Windows.Controls;

namespace DynamicUICore
{
	public class DynamicCheckBox : CheckBox, IDynamicControl
	{
		public DynamicCheckBox()
		{
			// TODO: Hook into the ancestor control's state change event (e.g., "TextChanged"), and from that handler call "" (passing in the property that represents the state of this control);
			Checked += StateChangedHandler;
			Unchecked += StateChangedHandler;
		}

		public void StateChangedHandler(object o1, object o2)
		{
			// TODO: Call "this.SaveValue" (passing in the CheckBox property that represents the state of this control);
			this.SaveValue(IsChecked);
			StateChanged?.Invoke(this, EventArgs.Empty);
		}

		public DynamicCheckBox(Blueprint blueprint) : this()
		{
			this.Initialize(blueprint);
		}

		public void Revert()
		{
			LoadValue(OriginalValue);
		}

		public void LoadValue(object value)
		{
			// TODO: Cast value to the type of the IsChecked property.
			IsChecked = (bool)value;
		}

        public Blueprint Blueprint { get; set; }
        public object OriginalValue { get; set; }

		public event EventHandler StateChanged;
	}
}
