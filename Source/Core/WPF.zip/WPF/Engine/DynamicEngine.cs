﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DynamicUICore
{
	public static class DynamicEngine
	{
        static IDynamicControl GetDynamicControl(DependencyObject parent)
        {
            IDynamicControl iDynamicParent = parent as IDynamicControl;
            if (iDynamicParent != null)
                return iDynamicParent;

            var numChildren = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numChildren; i++)
            {
                DependencyObject childControl = VisualTreeHelper.GetChild(parent, i);
                IDynamicControl iDynamicControl = childControl as IDynamicControl;
                if (iDynamicControl != null)
                    return iDynamicControl;

                iDynamicControl = GetDynamicControl(childControl);
                if (iDynamicControl != null)
                    return iDynamicControl;
            }
            return null;
        }

        static Visibility GetDynamicVisibility(DependencyObject parent)
        {
            IDynamicControl dynamicControl = GetDynamicControl(parent);
            if (dynamicControl != null)
                if (!dynamicControl.Blueprint.IsVisible())
                    return Visibility.Collapsed;

            return Visibility.Visible;
        }

        /// <summary>
        /// Sets the child visibility of dynamic UI elements, based on calling GetVisible method/property specified in UIAttribute.
        /// </summary>
        public static void SetChildVisibility(DependencyObject parent)
        {
            if (parent == null)
                return;

            var numChildren = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numChildren; i++)
            {
                FrameworkElement frameworkElement = VisualTreeHelper.GetChild(parent, i) as FrameworkElement;

                if (frameworkElement != null)
                    frameworkElement.Visibility = GetDynamicVisibility(frameworkElement);
            }
        }

        static void InternalStateChangeHandler(object sender, EventArgs e)
        {
            SetChildVisibility(Panel);
        }

        static void HookStateChangedEvents(this IDynamicControl iDynamicControl, EventHandler StateChangeHandler)
        {
            iDynamicControl.StateChanged += StateChangeHandler;
            iDynamicControl.StateChanged += InternalStateChangeHandler;
        }

        static FrameworkElement GetCheckbox(Blueprint blueprint, EventHandler StateChangeHandler)
		{
			// TODO: cb type shortcut for CheckBox
			DynamicCheckBox checkBox = new DynamicCheckBox(blueprint);
            checkBox.Margin = new Thickness(4);
            checkBox.Content = blueprint.UIAttribute.DisplayText;
            checkBox.HookStateChangedEvents(StateChangeHandler);
			return checkBox;
		}

		static FrameworkElement GetDoubleTextbox(Blueprint blueprint, EventHandler StateChangeHandler)
		{
			StackPanel stackPanel = GetLabeledStackPanel(blueprint.UIAttribute);

			// TODO: tx type shortcut for TextBox
			try
			{
				DynamicDoubleTextBox textBox = new DynamicDoubleTextBox(blueprint);
				textBox.Margin = new Thickness(0, 3, 0, 0);

				textBox.HookStateChangedEvents(StateChangeHandler);
                stackPanel.Children.Add(textBox);
			}
			catch (Exception ex)
			{
				AddExceptionDetail(stackPanel, ex);
			}

			return stackPanel;
		}

		static FrameworkElement GetColorTextbox(Blueprint blueprint, EventHandler StateChangeHandler)
		{
			StackPanel stackPanel = GetLabeledStackPanel(blueprint.UIAttribute);

			// TODO: tx type shortcut for TextBox
			try
			{
				DynamicColorTextBox textBox = new DynamicColorTextBox(blueprint);
				textBox.Margin = new Thickness(0, 3, 0, 0);

                textBox.HookStateChangedEvents(StateChangeHandler);
                stackPanel.Children.Add(textBox);
				System.Windows.Shapes.Ellipse shape = new System.Windows.Shapes.Ellipse() { Width = 22, Height = 22, Margin = new Thickness(4, 2, 0, 0) };
				textBox.SwatchShape = shape;
				stackPanel.Children.Add(shape);
			}
			catch (Exception ex)
			{
				AddExceptionDetail(stackPanel, ex);
			}

			return stackPanel;
		}

		static FrameworkElement GetTextbox(Blueprint blueprint, EventHandler StateChangeHandler)
		{
			StackPanel stackPanel = GetLabeledStackPanel(blueprint.UIAttribute);

			// TODO: tx type shortcut for TextBox
			try
			{
				DynamicTextBox textBox = new DynamicTextBox(blueprint);
				textBox.Margin = new Thickness(0, 3, 0, 0);
				textBox.HookStateChangedEvents(StateChangeHandler);
                stackPanel.Children.Add(textBox);
			}
			catch (Exception ex)
			{
				AddExceptionDetail(stackPanel, ex);
			}

			return stackPanel;
		}

		private static void AddExceptionDetail(StackPanel stackPanel, Exception ex)
		{
			TextBlock warningBlock = new TextBlock();
			warningBlock.Foreground = new SolidColorBrush(Color.FromRgb(148, 0, 0));
			warningBlock.Background = new SolidColorBrush(Color.FromRgb(255, 247, 247));
			warningBlock.Margin = new Thickness(4);
			warningBlock.Text = "Error getting value: " + ex.Message;
			stackPanel.Children.Add(warningBlock);
		}

		private static StackPanel GetLabeledStackPanel(UIAttribute uiAttribute)
		{
			// TODO: sp type shortcut for StackPanel
			StackPanel stackPanel = new StackPanel();
			stackPanel.Orientation = Orientation.Horizontal;

			// TODO: tb type shortcut for TextBlock
			TextBlock label = new TextBlock();
			label.Text = uiAttribute.DisplayText;
			label.Margin = new Thickness(4);
			stackPanel.Children.Add(label);
			return stackPanel;
		}

		public static FrameworkElement BuildUI(Blueprint blueprint, EventHandler StateChangeHandler)
		{
			UIElementType kind;
			if (blueprint.UIAttribute.Kind == UIElementType.Auto)
				kind = GetUIElementType(blueprint.Property.PropertyType);
			else
				kind = blueprint.UIAttribute.Kind;

			switch (kind)
			{
				case UIElementType.Checkbox:
					return GetCheckbox(blueprint, StateChangeHandler);
				case UIElementType.DoubleTextBox:
					return GetDoubleTextbox(blueprint, StateChangeHandler);
				case UIElementType.TextBox:
					return GetTextbox(blueprint, StateChangeHandler);
				case UIElementType.ColorTextBox:
					return GetColorTextbox(blueprint, StateChangeHandler);
                case UIElementType.Enum:
                    return GetButtonArray(blueprint, StateChangeHandler);
            }
			return null;
		}

        private static FrameworkElement GetButtonArray(Blueprint blueprint, EventHandler StateChangeHandler)
        {
            var uiAttribute = blueprint.UIAttribute;
            DynamicButtonArray buttons = new DynamicButtonArray()
                                           { DisplayText = uiAttribute.DisplayText, 
                                             EnumOptions = uiAttribute.EnumOptions, 
                                             EnumLayout = uiAttribute.EnumLayout,
                                             Blueprint = blueprint };
            buttons.InitializeValue();
            buttons.HookStateChangedEvents(StateChangeHandler);
            return buttons;
        }

        public static void SetParentPanel(Panel panel)
        {
            Panel = panel;
        }
        public static Panel Panel { get; set; }
        public static UIElementType GetUIElementType(Type propertyType)
		{
			if (propertyType.IsEnum)
				return UIElementType.Enum;

			if (propertyType.FullName == "System.Boolean")
				return UIElementType.Checkbox;

            if (propertyType.FullName == "System.Double")
                return UIElementType.DoubleTextBox;

            if (propertyType.FullName == "System.Windows.Media.Color")
				return UIElementType.ColorTextBox;

			return UIElementType.TextBox;
		}
	}
}
